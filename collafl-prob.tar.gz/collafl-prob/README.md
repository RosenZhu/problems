# collafl-dyninst
use dyninst to implement CollAFL

export COLL_PATH=/apps/collafl-dyninst
export PATH=$PATH:$COLL_PATH
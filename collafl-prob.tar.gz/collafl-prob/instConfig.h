

#define NUM_EDGE_FILE "num_edges.txt"
#define INDIRECT_ADDR_ID "indirect_addr_ids.txt"

// carefully
#define NUM_INDIRECT_TARGETS 5
#define MAX_PATH (1<<16)
#define N_PERCENT_100 1

